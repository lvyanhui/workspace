#!/bin/bash
cp -f libtermb.so /usr/lib/libtermb.so
